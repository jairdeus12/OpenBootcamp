package com.Java;

public class Tema1 {
    public static void main(String[] args) {
        System.out.println("Tipos de datos");
        byte num1 = 1;
        short num2 = 2;
        int num3 = 4;
        long num4 = 8L;


        double num5 = 9.99d;
        float num6 = 4.9f;

        char char1 = 'a';

        boolean true1 = true;
        boolean false1 = false;

        String palabra = "palabra";

        Long num7 = null;
        Integer num8 = null;







    }
}
