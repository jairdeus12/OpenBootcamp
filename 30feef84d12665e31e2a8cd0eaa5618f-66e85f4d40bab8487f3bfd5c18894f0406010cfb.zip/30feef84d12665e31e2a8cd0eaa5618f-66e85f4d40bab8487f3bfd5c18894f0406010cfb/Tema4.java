package com.OpenBootCamp;

public class Tema4 {
    public static void main(String[] args) {
        System.out.println("--------Caso If---------");
        int numeroIf = -1;

        if (numeroIf <0) {
            System.out.println("Negativo");
        } else if (numeroIf > 0) {
            System.out.println("Positivo");
        }else {
            System.out.println("El numero es 0");
        }

        System.out.println("----------Caso While---------------");

        //While

        int numeroWhile = 0;

        while (numeroWhile < 3){
            numeroWhile++;
            System.out.println(numeroWhile);

        }
        System.out.println("--------caso Do While-------");

        int numeroDoWhile = 0;

        do {
            numeroDoWhile++;
            System.out.println(numeroDoWhile);
        } while (numeroDoWhile >3); // de esta forma solo se podra ejecutar 1 vez.

        System.out.println("----------caso for----------");

        int numeroFor = 0;
        for (int i = 0; numeroFor <= 3; numeroFor++) {
            System.out.println("el valor de numeroFor es: " + numeroFor);

        }
        System.out.println("--------Caso Switch---------");

        String estacion = "Primavera";

        switch (estacion){
            case "Verano":
                System.out.println("Es Verano !");
                break;
            case "Otoño":
                System.out.println("Es Otoño!");
                break;
            case "Invierno":
                System.out.println("Es Invierno!");
                break;
            case "Primavera":
                System.out.println("Es Primavera!");
            default:
                System.out.println("No es una estacion :(");
        }
    }
}